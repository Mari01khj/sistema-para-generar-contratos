<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Exige que exista una sesión iniciada.
 * Si no la hay, manda al login (sin importar qué URL se haya escrito).
 */
class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! session()->get('isLoggedIn')) {
            return redirect()->to(route_to('loginForm'))
                ->with('error', 'Debe iniciar sesión para tener acceso.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Páginas privadas: que el navegador NO las guarde en caché.
        // Así, tras cerrar sesión, el botón "Atrás" no muestra el dashboard anterior.
        $response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->setHeader('Pragma', 'no-cache');
        $response->setHeader('Expires', '0');

        return $response;
    }
}
