<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Restringe una ruta a ciertos roles.
 *
 * Uso en Routes.php:
 *   ['filter' => 'roleFilter:1']     -> solo Administrador
 *   ['filter' => 'roleFilter:2']     -> solo Operador
 *   ['filter' => 'roleFilter:1,2']   -> Administrador u Operador
 */
class RoleFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Defensa extra: aunque esta ruta se use sin AuthFilter, nunca deja pasar a un anónimo.
        if (! session()->get('isLoggedIn')) {
            return redirect()->to(route_to('loginForm'))
                ->with('error', 'Debe iniciar sesión para tener acceso.');
        }

        $rolUsuario    = (int) session()->get('rol_id');
        $rolesPermitidos = array_map('intval', (array) $arguments);

        if (! in_array($rolUsuario, $rolesPermitidos, true)) {
            // Está logueado pero no le toca esta sección: lo devolvemos a SU dashboard.
            helper('sesion');

            return redirect()->to(ruta_dashboard($rolUsuario))
                ->with('error', 'No tiene permisos para acceder a esa sección.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
