<?php

namespace App\Controllers;

class Home extends BaseController
{
    /**
     * "/" y "/dashboard": no muestran nada por sí mismos,
     * solo envían a cada usuario a SU dashboard según su rol.
     */
    public function index()
    {
        helper('sesion');

        return redirect()->to(ruta_dashboard());
    }
}
